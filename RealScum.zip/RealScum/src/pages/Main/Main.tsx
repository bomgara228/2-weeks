import { Route, Routes } from 'react-router-dom'
import style from './Main.module.css';
import { NOUDONT,instance } from '../../api'
import Larr from "../../images/ArrowL.png"
import Rarr from "../../images/ArrowR.png"
import { useState } from 'react';

const Main = () => {
    const [gamegame,setGamegame] = useState()
    instance.get('https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps')
            .then(({ data }) => setGamegame(data))
    interface MainInterface {
        name: string
        price: string
        MainImg:string
        img1: string
        img2: string
        img3: string
        img4: string
    }
    
    //@ts-ignore
    const [filterPosts, setFilterPosts] = useState<MainInterface[]>( gamegame)
    function bigTablo()
     { filterPosts.map((item: MainInterface, index: number) => (
            <li  className={style.item}>
                <h2>{item.name}</h2>
                <h3>{item.price}</h3>
                <img src={item.MainImg} alt="" />
                <img src={item.img1} alt="" />
                <img src={item.img2} alt="" />
                <img src={item.img3} alt="" />
                <img src={item.img4} alt="" />
                <img src={item.img1} alt="" />
            </li>
    ))}
    return (
        /* allGames.then(function (result) { console.log(result) }) */
        
        <div className={style.center}>
            <p className={style.tx}>POPULAR AND RECOMMENDED</p>
            <div className={style.stoiRovno}>
                <img src={Larr} alt="strelkal" className={style.streloski} />
                <div className={style.megaBox}>
                <>
                {bigTablo()}
                </>
                </div>
                <img src={Rarr} alt="strelkar" className={style.streloskir}/>
            </div>
        </div>
    )
}
export default Main