import React, { Component } from 'react';
import { Button } from '../Button/Button';
interface Props {
    title: string
}

interface StateType {
    title: string,
    count: number,
    isShow: boolean
}

export class ComponentClass extends Component<Props, StateType> {

    state = {
        title: "class title",
        count: 0,
        isShow: false
    }

    addOne = (num: number) => {
        this.setState({
            count: this.state.count + num
        })
    }

    switch = () => {
        this.setState({
            isShow: !this.state.isShow
        })
    }

    render() {

        const { title } = this.props

        return (
            <div>
                <h3>{this.state.title}</h3>
                <h4>props title - {title}</h4>
                test class component
                <p>count - {this.state.count}</p>
                <button onClick={() => this.addOne(1)}>+1</button>
                <Button click={() => this.addOne(-1)}>-1</Button>
            </div>
        )
    }
}