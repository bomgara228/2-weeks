import styles from './Footer.module.css'

export const Footer = () => (
  <footer className={styles.footerWrapper}>
    footer
  </footer>
)