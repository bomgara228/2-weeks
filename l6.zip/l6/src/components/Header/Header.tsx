import { NavLink, Link } from "react-router-dom";
import style from './Header.module.css';
import logoImg from '../../assets/images/logo.png';
import {Clock} from '../Clock/Clock';

export const Header = () => (
    <header className={style.headerWrapper}>
         <Clock/>
        <div>
            <img
                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA8FBMVEXgmV7///9PXXN3s9S6gVFGUGJmlbBMXHPnnF1qZ3C8glCmelhHW3XXlFvek1LflVbBjGPekU2CcG18bm7249Xoto/57eRajqv9+vfhnGJvr9Lkp3brvp3y1sL79O7sw6TmrYFLV2viom335dg+T2g/Sl1udYLns4rvy7FEVGxqnLg1QVbz2snlqnw+WHRhZHHp6u19hpXC091sc4COdWvRkmCzhWa7iWSgfWnLztTZ5OqowdCqsLlwp8Wfo6unzOLh7fXO4u66vcKTd2ra3OCKk6BbaHyPsMN9pLuvxdPGytCDiZWIq8CmqbGTwtyw0uW0U5CfAAAOMUlEQVR4nOWdCVvbRhPHJYMr4xgJBcv4PmQbbGzAhNCcTYAcpDRNv/+3eXVY9urY3dnVCMl5/8/TPk+Nj/11Zmd29pKiZq5mf7zszbrWsGPbrZbSatl2Z2h1Z73luN/M/ueVLL+8P+51L1qGqeuGYShhOa/oumm0Lrq9cT/LRmRF2F8OLhy0GFhcDqlpXAyWWWFmQdjvWS3HbFy2EKeut7qZUGITNusD2xSk21KadreO3CBcwubSMiTptpSGtcRsEybh8kzUNemQiJbEIhx301ovAjloILUMh7Bnm3h4a0iz00NpGwJhf2boyHi+dGOGMCJITdiwEL0zKkO3UjtrSsLGGbp7RhjNs5SMqQgbZxnab8Oop2NMQdjP2n4bRvMsxWBHmrA5eAb7bRj1wbMT9gBjalRGQzZ3yBE27GzyA0u6LdcdpQi75rPzuTK7z0RYV57XQbcyFInxqjihlY8BfUmYUZSw0crLgL6MlmhvFCSc5WlAX+YsQ8Jm5/lDaFx6R2g8LkI4ztdBtzLG2RAWwEMDiXgqnHBYBA8NpA/RCZt2UVzUl2FDOyOQsFEsPlcGMG3ACOtF8tBAOmyAAyLsFSfGkDJB5QaEsEBBNCxQSAUQFhYQhsgnLDAgCJFLWGhACCKPsOCAAEQOYUGjKCleRGUT7gAgF5FJON4FQAeRWWqwCBtFHMkkSWcN4BiEzbwbLiDGMJxBaOfdbAHZMoTD4pUTdBn0epFKONuVTuhLp6ZFGmF9N8LoViatlqIQNnfJRX0ZlGhDIdylKBOoI0I42K1O6IuyxphIuCNjmaiSxzaJhHk3VVYtKKG1e2HGl2HBCHcuUWyVlDISCHfVgp4ghF18wopyewTRYSXtLxnxFdQYYQPfRytvS5c1gC5rx7dpGeOFVIwwg1x/UNNKMGmXf6ZFjFUZUcIeeq6vHNSAfK4uj1Ii6tE5jQgh/ni08vZSALCkaYcpfzA6Po0QDtAJD0Us6Kj2OqURjQGLsI/vo68FCUuXtyl/Uu8zCM/wMwU0yGyN+CWtEc/ohPiZovJW1ISO0v6o2aAS4puwciVsw1ItdcYY0giF5kcrESW/61bChNoBatonCQVMWLn988vL461evz1KghSPM64uj1IShoxIEMJ7YeX2wBlkaYScIddVgnOJpgosI5I9kSAEl4WVN5cJvUu7jGUyORM6RnyTNpxaSYTwXEizTGxQeSQHWNJSh1MiJ24JZ2ATfqE0XLuKEJbEA6mvWlo/JQY2W0KwCekZIDQcqRxKZIoN4nE6QkWPE4KLikqF2vDaEZE+3khb0Puqq6NoPmJlpThhL0bYAfIdvX1Nbbl28HKt1y9L4KKQ8l210su43KwEa2gnSghLFZXDA6daZzRrkz20dHyhLwtnpWPYXMcmYQSEoNmZylFKw2BIq4HMuJmxCQhBgfRWqJjNShqsvjLChEtInJEZRmehWFZKVLB1cU0IGZJKVUKZCFR9BGWiT9gEmTBV+MeUVgIZsUkQgpz0qBC90BOo+tCXBCHISWmDNTFp8/kk0Hwu6RW1txA3tQhCUKo4Tu2k2nyinX56ePd1tWquVquvD59OSxMZSu0YlDC2hKBt3JWDlIOU+eT041c1qtXDqTgkrIL0o6lHCJolTUeoTW4eqBuXHm4mYt8NI/QLDI8QtFaRhlCbXMetR+rrtRAjcBbADgj7sDGpNCGXz/NWEUYgodlfE8IKJ2nCufaOy+fqqTRHJvRKKJcQNkEjSzj5BuJz9W2CS+jlC5ewBXm3JKE2hxlwbUagp0Jn41o+IXAKSopw/n0lAOj0xu8gT4USuhNSCnDIJkc4PxXic3UKQQQTLj1C4JqhBCENcPXeFcW61wBEKKGbERX4DI0wYSLg+w8/TgKdf3glhwieFe94hMBJNmFC7Xsc79Hh+oPQycnj+7ijcn8ITKi7hLB8L2PD6Cjt1XmILoD8I2ZIbiEKJnRyvgI+PSlKOImMY1Y/kvg8xh93kbfy8iLchnWHEDqbL0g4+Rhu9d80Po/xQ/jNDxxEMKExcwihS05ihNp1uM1UAwZmDL/9mv1bcELLIQSGUkHCSSgXrJh4vsIfYBsRvsLYcQhhYzZBwnnIR1dsAyYhfmSmDDhhS1VA02zChKWQz0VQzs//cnV+Hnk99BlmPIUT6k0FvD1BhHD+QAM8/2uP1F8k5Xko2LCMKEDYUMBH7UUINbKtj1sfDeOtIbfh5pH8GBJhXYGvG8IJQ73w1QmLL8R4QuZ+Vk8UIOwp8MVtOGEokAaA5xQ+V4GvngDDKZzQmCng3YhwwlAuDHyUZsCQGUOZn5ETBQgHCnhbN5xw/kRYAgS4RSSs/0R3UwHCrmIB3ypAOCGG3I9+yzl8ruJGpLupwJ4iSxmiE4ac9AQKGCASn6VXUQKEQwU6aIMTkpHUD6Q8FyUclQyn/1LdVICwo4D35oMJybLpJy+KxhB/bj/8rrCERLQ4Afto4KeEm9LzhQChrUAH3gJeum3j+xOwjwZGPCFmNTD6YQufkJyeccteqI+6Og93xO+0XxQiBAtM+M+2iR9EfHTtp0S+oAZToR2o6DacE+sUP8VM6BmRCDXfaKEmXy+df9o28YdIL3Tl9ERiPuMTCiF6LC2HCYUAXTc9xyW08Qmn30hCMSd13ZQknGIQoo9pwoRiTuq66Q9cwo5ygU5IxNJHCUIy0iAQXuDXFtMbIlucCALu7ZHVxTUCoYVfH5ZH2ya+kiAkMv5VekKnPkSv8cuLbRPvJAiJUVu5nJ5wgD9PU16QI29hQmLWdLVAIJwpPXxCYhLjUZiQrJ4QCPUl/nxpeUqk/FdtQcA2WQFPEQjr+HPe5TIRTFVhQuKzpxiEDfx1i3KoI34WQ2x/JggXCJFGb+KvPTmExKrFSpCQWA1+wiBsZbB+WC5PyT0YQkYMmfB6ikDYyWANeBR2U6GeSPZCJ1eUR2kJvTVg7HV8h5CMpuo9HLF9T3zOiaQIhLMs9mKUHUSipeovKGL7F/kxB5DmpIJ7MdD30zgtW4QWucE2JD/0sMAg9PbToO+JKkeNCERshxby3W9BsGEm+9pG5UhPVO8gftoObRv61zUhrRuK7mtD35vo/t8PhVP1DkAY3m2yYJlQdG8i+v5Sz03JoZvrqGwztvfCbz+dohCu95ei7xEelWPBRlX/YyG2/wu/+aNnQqqTiu4Rxt/n7UWJRWTn3h3VjO29yM69rwtmnBHe542/V98z4nSkRnSfyNjeu4++cTRlm1B4rz7+eQvPBNOraMvV+1/tNknp/NevGJ96NeWYUPi8Bf6ZmZGPmLQL+v6zy+Vr73McT1VvfECGCYXPzMA6otC+tjId0dHd3d2980/yH/0wyjSh8Lkn4FF1EcJRmeaoPAWALBNCz651N4QZnD8MEEeCJ0rWfZBtQvHzh7AzpGK7oNcNnU5FTgW9m4IAoTZUt4SQfCG6k33d1PICfrLr0yL4ENNHgYShc8CQgZso4Sho7XT0xMLaGrA8BQLCCENnuSFuKnzeYoNYXtwATliebgzIBQTaUCUJAW4qfqJkizhd8E7J/rPYGJDXCYGEwV1R8HsxJE52bdvsMDJOOj/dkHx8QBDh2kkF7jaROZ03CjEuTh/iuWP1cLoI8QEAYTZUw4T8MljqhCWJ6EGO/BsHmmrTv3FgFMHj90Eg4eYuLPgdQ3KnZMOILqWDudF0Gv0zCBBCGLtjiD9bI3vSOcrAFPA7AYSxe6L4JZT0afWYGamCGRBEmHDXFzfWpLhTAdeAMEI1Tsib3U91twmmAV3ClxzCxDv3eBNSKS9RQrOfK+79NIn3JnLHNfspb+Ch90cR8/mE+xwTJt59yU0Y1fRX8IzilCNhPPcCniq7qZT7S3l3KVX3cW7CGrkqe/+W/Yp9DiHlDlrePcLV6otCXGem1V5U2YTUe4Q5RqzuV1+UcmfUaqUXVY4NqXdBc3pidX+/Wv1yBXmOQ4a6+lJ1G8JqKOM+b7YRD/f3Xcb9F3nKbYAj1uMFWHeyc3Livq9qnlq3gdVM5r367CIq+Pr8xXJS9rMROM+3yBtsI1YjOc+3YJcYh3mTrcXqhbxnlHDubisGIvMpJtznzPDGbod5d8Yq+yktJv9ZQfxlmsM8xWkb5HlPu/tcOU8JOPGXfv/nrv3+z87bYT9NhEl68fd/huXv/xxS8G6+QknoWbL/B88D3r2UkdwJGYS//3O5M3kGW3aK1PUwwp16cnWsogARNvNutoCoC+hMQrHnsOWp+ONVgYS7ElCTxttAQrW3C4hmdN5ChHAXEDmAPEJ1VnREk5oIgYRFR+QC8gmLjcgHBBAWGREACCEsbrjhBRkwYVERzSWk8SBCdVzE0Y1Oq5dkCNVG3jgJYg3VxAnVpl2sYsqwGYNtKUJVHRbJU/Uhv8HChEXKGpAsIUGo1oviqAazmEhBqPbtIniqbvf5TZUkVNVB/p5qJk/8YhGq41a+rmq0YFlQnlBVrTzNaCatLmETqnUlLzMaikiIkSfMbeGGsvSSBaHayCGo6jZwmIZC6JQbz+yqhgKplDAJXVd9PkZDzkFTEqr9s+eKquaZUI5HI3S647OMxvWhXAfEIHQZzWx91TDT8aUmdBitDPujoVsp+RAInf440LNxVl0fpOh/iISOeh10QxpmRzY/hIVD6DhrF9OQhm4MUrvnWliEjpZDHcWSDt4ZaJ4QJkRCVW0uz4yUkM7nLUQ8FZnQVX1gm5KUhm7aXYnqgS10Qkf9ntUSdVhD11vWEiF0xpQFoav+cnBhOMbkcxqO6YyLQSZ0rrIi9NSvz6yOopuOQWOoziu68xelY83qWcF5ypTQV7M/XvZmXWvYse1WS2m1bLsztLqz3nLch05cp9D/ADtZvtZ81URTAAAAAElFTkSuQmCC"
                alt="тест 1"
                width={30}
                height={30}
            />
            <img
                src={logoImg}
                width={30}
                height={30}
                alt=""
            />
        </div>
        <nav className={style.nav}>
            <div className={style.linkContainer}>
                <NavLink
                    className={({ isActive }) => (isActive ? style.active : style.link)}
                    to="/"
                >Home</NavLink>
            </div>
            <div className={style.linkContainer}>
                <NavLink
                    className={({ isActive }) => (isActive ? style.active : style.link)}
                    to="/todolist"
                >TodoList</NavLink>
            </div>
            <div className={style.linkContainer}>
                <NavLink
                    className={({ isActive }) => (isActive ? style.active : style.link)}
                    to="/posts"
                >Posts</NavLink>
            </div>
            <div className={style.linkContainer}>
                <NavLink
                    className={({ isActive }) => (isActive ? style.active : style.link)}
                    to="/blog"
                >Blog</NavLink>
            </div>
            {/* <div className={style.linkContainer}>
            <Link
                className={style.link}
                to="/todolist"
            >TodoList</Link>
        </div> */}
        </nav>
    </header>
)