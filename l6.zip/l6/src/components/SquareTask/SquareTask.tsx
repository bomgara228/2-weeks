import { useEffect, useRef, useState } from "react"
import styles from "./SquareTask.module.css"
import { Button } from "../Button/Button"

export const Square=()=>{
    
    const [size,setSize]=useState<number>(100)
    const [rotation,setRotation]=useState<number>(0)
    const [year,setYear]=useState<number>(0)
    const [month,setMonth]=useState<number>(0)
    const [day,setDay]=useState<number>(0)
    const [color,setColor]=useState<string>('')
    const [isPassword,setIsPassword]=useState<boolean>(true)

    const sizeInput = useRef<HTMLInputElement | null>(null)
    const rotationInput = useRef<HTMLInputElement | null>(null)
    const square = useRef<HTMLDivElement | null>(null)

    function changeColor(event:any){
        setColor(event.target.value)
    }
    function changeDate(event:any){
        setYear(Number((event.target.value).slice(0,4)))
        setMonth(Number((event.target.value).slice(5,7)))
        setDay(Number((event.target.value).slice(8,10)))
    }
    function changeType(){
        setIsPassword(!isPassword)
    }

    function changeSize(){
        if(sizeInput.current)
        setSize(Number(sizeInput?.current?.value))
    }
    function changeRotation(){
        if(rotationInput.current)
        setRotation(Number(rotationInput?.current?.value))
    }
    useEffect(()=>{
        if(square.current){
            square.current.style.transform = `rotateZ(${rotation}deg)`
            square.current.style.height = `${size}px`
            square.current.style.width = `${size}px`
            square.current.style.backgroundColor = `${color}`
        }
    },[size,rotation,color])

    return(
        <>
        <div>
            <input ref={sizeInput} onChange={changeSize} type="range" id="size" name="size" min="1" max="800"  step='1'/>
            <span>{size}</span>
        </div>

        <div>
            <input ref={rotationInput} onChange={changeRotation} type="range" id="rotation" name="rotation" min="0" max="360" step="1" />
            <span>{rotation}</span>
        </div>

        <input onInput={changeColor} type="color" />
        <input onInput={changeDate} type="date"></input>
        <div>
            <input type={isPassword?"password":"text"}  />
            <button onClick={changeType}>change</button>
        </div>

        <div ref={square} className={styles.square}>
            <h5>Year:{year}</h5>
            <h5>Month:{month}</h5>
            <h5>Day:{day}</h5>
        </div>

        </>
    )
}