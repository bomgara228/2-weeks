import { UserItem } from '../components/UserItem/UserItem';
import { useEffect, useState, Fragment, useContext } from "react";
import { v4 as uuidv4 } from 'uuid';
import { instance } from '../api'
import { AppContext } from '../App'
import { useDispatch } from 'react-redux'
import { incremented, setNewValue, setDouble } from '../store';

 const Home = () => {
    const dispatch = useDispatch()

    const { test, age } = useContext(AppContext)

    const [postsList, setPostsList] = useState([])

    let id = 100

    const updateValue = () => {
        dispatch(incremented())
    }


    const setNum = () => {
        dispatch(setNewValue(100))
    }

    const setDoubleH = () => {
        dispatch(setDouble({
            name: "alesia",
            count: 1000,
        }))
    }

    useEffect(() => {
        instance.get('/todos')
            .then(({ data }) => setPostsList(data))
            .catch(e => console.log(e))
    }, [])

    return (
        <div>


            <button onClick={updateValue}>+1</button>

            <button onClick={setNum}>+100</button>

            <button onClick={setDoubleH}>double</button>
            <h4>{test} - {age}</h4>
            <div>
                <ul>
                    {postsList.map((item) => {
                        return (
                            <UserItem key={uuidv4()} item={item} />
                        )
                    })}
                </ul>
            </div>

        </div>
    )
}
export default Home