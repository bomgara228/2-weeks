import React, { useEffect, useState, useRef } from 'react';
import { Button } from '../components/Button/Button';
import MouseMove from '../components/MouseMove/MouseMove';
import {ClockAlternanative} from '../components/ClockAlternanative/ClockAlternanative';
import { ListItem } from '../components/ListItem/ListItem';
import { ComponentClass } from '../components/ComponentClass/ComponentClass';
import { v4 as uuidv4 } from 'uuid';
import styles from '../App.module.css'
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useSelector } from 'react-redux'
import { Square } from '../components/SquareTask/SquareTask';
import {CSSTransition,TransitionGroup} from 'react-transition-group'
import '../index.css'

const sortList=['All','Done','ToDo']
const startList = [
    {
        id: 1,
        title: 'купить хлеб',
        isDone: false,
    },
    {
        id: 2,
        title: 'купить молоко',
        isDone: true,
    },
    {
        id: 3,
        title: 'Погулять с собакой',
        isDone: false,
    },
]


 const ToDoList = () => {
    //@ts-ignore
    const {name, value, isLoading} = useSelector(store => store)

    const { search } = useLocation()
    const navigate = useNavigate()

    const [list, setList] = useState(startList)
    const [sortedList, setsortedList] = useState(list)

    const [newText, setnewText] = useState('')
    const [sort, setSort] = useState('All')

    /////////////////////////////////
    const [count, setCount] = useState(1)

    const refDiv = useRef(null)
    const refInput = useRef(null)

    const addNewItem = () => {

        if (!newText.trim()) return

        const obj = {
            id: uuidv4(),
            title: newText,
            isDone: false,
        }
        setList([...list, obj])
        setnewText('')
    }

    const updateStatus = (status, id) => {
        const newList = list.map((item) => item.id === id ? { ...item, isDone: status } : item)
        setList(newList)
    }

    const updateItemText = (title, id) => {
        const newList = list.map((item) => item.id === id ? { ...item, title, } : item)
        setList(newList)
    }

    const deleteByid = (id) => {
        const filteredList = list.filter((item) => id !== item.id)
        setList(filteredList)
    }

    const addItemOnEnterPree = (event) => {
        if (event.key === 'Enter' || event.charCode === 13) {
            addNewItem()
        }
    }

    const showRefInfo = () => {
        refDiv.current.classList.add('test21')
    }

    const goToUserIngoPage = () => {
        navigate(`/user/${count}`)
    }

    const setNewCount = () => {
        setCount((prev) => prev + 1)
    }

    useEffect(() => {
        setsortedList(list)

        if (sort.toLowerCase() === "Done".toLowerCase()) {
            setsortedList(list.filter(item => item.isDone === true))
        }

        if (sort.toLowerCase() === "ToDo".toLowerCase()) {
            setsortedList(list.filter(item => item.isDone !== true))
        }
    }, [sort, list])

    useEffect(() => {
        // const startSort = location.search.replace('?sort=', "")
        const query = new URLSearchParams(search).get('sort') ?? ''
        const countQuery = new URLSearchParams(search).get('count')
        setCount(+countQuery)
        setSort(query.toLowerCase())
    }, [])

    return (
        <div>
            <main className={styles.main}>
                <div>
                name - {name}, age - {value}
                </div>

                <Outlet/>
                <NavLink to='/todolist/news'>news</NavLink>

                <div style={{background: '#333'}}><ClockAlternanative /></div>

                <h1>{sort}</h1>

                {count}{" "}
                <Button click={goToUserIngoPage}>go to user</Button>
                <Button click={setNewCount}>+1</Button>

                <ComponentClass title="class title" />

                <div ref={refDiv} id="div_test" className="test">
                    <input
                        ref={refInput}
                        type="text"
                        value={newText}
                        onChange={(event) => setnewText(event.target.value)}
                        onKeyPress={addItemOnEnterPree}
                    />

                    <Button click={addNewItem} isDisabled={!newText}>
                        add new
                    </Button>
                </div>
                <Button click={showRefInfo}>showRef</Button>

                <ul>
                    {sortedList.length ? (
                        <TransitionGroup>
                            {
                                sortedList.map((item, index) => (
                                    <CSSTransition key={item.id} timeout={500} classNames='post'>
                                        <ListItem
                                            
                                            item={item}
                                            index={index}
                                            deleteByid={deleteByid}
                                            updateStatus={updateStatus}
                                            updateItemText={updateItemText}
                                        />
                                    </CSSTransition>
                                ))
                            }
                        </TransitionGroup>
                    ) : (<div>List is Empty</div>)}

                </ul>

                <div>
                    {sortList.map((item,index)=>(
                        <Button key={index} click={() => setSort(item)} isDisabled={sort === item}>{item}</Button>
                    ))}
                </div>
            </main>
            <Square></Square>
            <MouseMove />
            
        </div>
    )
}
export default ToDoList