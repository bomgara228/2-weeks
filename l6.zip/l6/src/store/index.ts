import { createSlice, configureStore } from '@reduxjs/toolkit'

const counterSlice = createSlice({
  name: 'counter',
  initialState: {
    value: 10,
    name: 'Vlad',
    isLoading: false,
  },
  reducers: {
    incremented: state => {
      state.value += 1
    },
    decremented: state => {
      state.value -= 1
    },
    setNewValue: (state, {payload}: any) => {
      state.value = payload
    },
    setName: (state) => {
      state.name = 'Dima'
    },
    setDouble: (state, {payload}) => {
      console.log("payload", payload)
      state.name = payload.name;
      state.value = payload.count;
    },
  }
})

export const { incremented, decremented, setName, setNewValue, setDouble } = counterSlice.actions

export const store = configureStore({
  reducer: counterSlice.reducer
})
